This directory is a convenient place to put fonts where ft2engine will find them. 
If running in a server environment, this is a good place to put TTF fonts needed 
by your application. If in a desktop environment, you might prefer to add
your font directories to the application preferences instead.

