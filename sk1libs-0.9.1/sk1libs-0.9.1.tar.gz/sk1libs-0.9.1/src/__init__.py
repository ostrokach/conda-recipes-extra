
import sys, libpdf
sys.modules['reportlab'] = libpdf